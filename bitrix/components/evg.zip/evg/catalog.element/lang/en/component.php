<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
$MESS ['CATALOG_ERROR2BASKET'] = "Could not add product to cart";
$MESS ['CATALOG_ELEMENT_NOT_FOUND'] = "Element has not been found.";
?>