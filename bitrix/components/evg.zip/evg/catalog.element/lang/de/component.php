<?
$MESS ['CATALOG_ERROR2BASKET'] = "Beim Hinzuf�gen des Produkts in den Warenkorb ist ein Fehler aufgetreten";
$MESS ['CATALOG_ELEMENT_NOT_FOUND'] = "Element wurde nicht gefunden.";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Das Modul \"Informationsbl�cke\" wurde nicht installiert";
?>