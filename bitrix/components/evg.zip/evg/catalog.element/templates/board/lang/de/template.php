<?
$MESS ['CATALOG_QUANTITY_FROM'] = "Von #FROM# ";
$MESS ['CATALOG_NOT_AVAILABLE'] = "(nicht auf Lager)";
$MESS ['CATALOG_ADD_TO_BASKET'] = "In Warenkorb";
$MESS ['CATALOG_BACK'] = "Zur�ck zum Bereich";
$MESS ['CATALOG_BUY'] = "Kaufen";
$MESS ['CATALOG_DOWNLOAD'] = "Download";
$MESS ['CATALOG_QUANTITY_FROM_TO'] = "Von #FROM# bis #TO#";
$MESS ['CATALOG_MORE_PHOTO'] = "Weiteres Foto";
$MESS ['CATALOG_NO_VAT'] = "Steuerfrei";
$MESS ['PUB_DATE'] = "Ver�ffentlichungsdatum:";
$MESS ['CATALOG_QUANTITY'] = "Anzahl";
$MESS ['CATALOG_PRICE_NOVAT'] = "Ohne MwSt.";
$MESS ['CATALOG_PRICE_VAT'] = "mit MwSt.";
$MESS ['CATALOG_VAT'] = "MwSt.";
$MESS ['CATALOG_VAT_INCLUDED'] = "inkl. MwSt.";
$MESS ['CATALOG_VAT_NOT_INCLUDED'] = "MwSt. ist im Preis nicht enthalten";
$MESS ['CATALOG_QUANTITY_TO'] = "Bis #TO#";
$MESS ['CT_BCE_QUANTITY'] = "Menge";
?>