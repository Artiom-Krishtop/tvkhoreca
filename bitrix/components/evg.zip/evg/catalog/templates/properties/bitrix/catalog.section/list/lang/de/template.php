<?
$MESS["CATALOG_BUY"] = "Kaufen";
$MESS["CATALOG_ADD"] = "In Warenkorb";
$MESS["CATALOG_NOT_AVAILABLE"] = "(nicht auf Lager)";
$MESS["CATALOG_TITLE"] = "�berschrift";
$MESS["CT_BCS_ELEMENT_DELETE_CONFIRM"] = "Alle mit diesem Eintrag verbundenen Informationen gehen verloren. Wollen Sie Fortfahren?";
?>