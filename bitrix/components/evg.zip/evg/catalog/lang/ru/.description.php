<?
$MESS ['IBLOCK_CATALOG_NAME'] = "Каталог";
$MESS ['IBLOCK_CATALOG_DESCRIPTION'] = "Полный каталог";
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Каталог";
?>