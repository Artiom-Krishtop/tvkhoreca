<?
$MESS["CT_BCSL_ELEMENT_DELETE_CONFIRM"] = "Alle mit diesem Eintrag verbundenen Informationen gehen verloren. Wollen Sie Fortfahren?";
?>