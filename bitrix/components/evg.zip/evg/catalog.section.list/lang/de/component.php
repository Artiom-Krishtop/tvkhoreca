<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Das Modul \"Informationsbl�cke\" wurde nicht installiert";
?>