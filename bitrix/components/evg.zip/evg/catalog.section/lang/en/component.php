<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
$MESS ['CATALOG_SECTION_NOT_FOUND'] = "Section has not been found.";
$MESS ['CATALOG_ERROR2BASKET'] = "Could not add product to cart";
?>