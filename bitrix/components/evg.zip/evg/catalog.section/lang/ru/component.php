<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Модуль Информационных блоков не установлен";
$MESS ['CATALOG_SECTION_NOT_FOUND'] = "Раздел не найден.";
$MESS ['CATALOG_ERROR2BASKET'] = "Ошибка добавления товара в корзину";
?>