<?
$MESS ['CATALOG_ERROR2BASKET'] = "Beim Hinzuf�gen des Produkts in den Warenkorb ist ein Fehler aufgetreten";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Das Modul \"Informationsbl�cke\" wurde nicht installiert";
$MESS ['CATALOG_SECTION_NOT_FOUND'] = "Bereich wurde nicht gefunden.";
?>