<?
$MESS["CATALOG_BUY"] = "Kaufen";
$MESS["CATALOG_ADD"] = "In Warenkorb";
$MESS["CATALOG_COMPARE"] = "Vergleichen";
$MESS["CATALOG_NOT_AVAILABLE"] = "(nicht auf Lager)";
$MESS["CATALOG_QUANTITY"] = "Anzahl";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "Von #FROM# bis #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "Von #FROM# ";
$MESS["CATALOG_QUANTITY_TO"] = "Bis #TO#";
$MESS["PUB_DATE"] = "Ver�ffentlichungsdatum:";
$MESS["CT_BCS_QUANTITY"] = "Menge";
$MESS["CT_BCS_ELEMENT_DELETE_CONFIRM"] = "Alle mit diesem Eintrag verbundenen Informationen gehen verloren. Wollen Sie Fortfahren?";
?>